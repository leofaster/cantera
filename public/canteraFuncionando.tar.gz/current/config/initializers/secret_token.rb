# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Current::Application.config.secret_token = 'adb6f26bbfc80621ffaae4322fbc98818b1c293af4b6c1b59ce95fa21de9d5c6d8b2b47f4ef89b31eca930b4fdab10b94ac091e46126c0743fb577ee00a02ae9'
